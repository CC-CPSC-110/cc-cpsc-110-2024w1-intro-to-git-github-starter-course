
from typing import List, Dict, Tuple
#2.1
def Average(lst: List[float]) -> float:
    """
    Purpose: Finds the index of a number that is closest to the average of a collection of numbers.
    
    Example:
    calculateAverage([1.0, 3.0, 5.0]) -> 3.0
    """
    return sum(lst) / len(lst)

#eg
print(Average([1.0, 3.0, 5.0]))

#2.2
def rangeBetween(start: int, end: int) -> List[int]:
    """
    Purpose: Takes a start and end index and produces a collection of all whole numbers between the indices.
    
    Example:
    rangeBetween(3, 7) -> [3, 4, 5, 6]
    """
    return list(range(start, end))
#eg
print(rangeBetween(3, 7))

#2.3
def addUniqueElement(lst: List[int], elem: int) -> List[int]:
    """
    Purpose: Adds an element to a collection only if the element doesn't already exist.
    
    Example:
    addUniqueElement([1, 2, 3], 2) -> [1, 2, 3]
    addUniqueElement([1, 2, 3], 4) -> [1, 2, 3, 4]
    """
    
    if elem not in lst:
        return lst + [elem]  
    return lst  
#eg
print(addUniqueElement([1, 2, 3], 2)) 
print(addUniqueElement([1, 2, 3], 4)) 

#2.4

def updateDictionary(d: Dict[str, int], key: str, value: int) -> Dict[str, int]:
    """
    Purpose: Takes a collection, a key, and a value and modifies the collection 
    where the key is associated with the value.
    
    Example:
    updateDictionary({"a": 1, "b": 2}, "c", 3) -> {"a": 1, "b": 2, "c": 3}
    """
    d[key] = value
    return d
# Example Test
print(updateDictionary({"a": 1, "b": 2}, "c", 3))  
print(updateDictionary({"a": 1, "b": 2}, "b", 5))  

#2.5
def immutablePair(a: int, b: int) -> tuple:
    """
    Purpose: Produces an immutable collection of the two numbers.
    
    Example:
    immutablePair(5, 10) -> (5, 10)
    """
    return (a, b)

#eg
print(immutablePair(5, 10))  
print(immutablePair(1, 2))   
