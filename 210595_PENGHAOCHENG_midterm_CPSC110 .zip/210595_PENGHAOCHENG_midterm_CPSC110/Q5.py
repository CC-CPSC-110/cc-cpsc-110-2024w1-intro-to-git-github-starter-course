def birthday_one_week_before(customer: Customer) -> str:
    """
    purpose: Produces a string representing the date (month and day) that is one week before the customer's birthday.
    expect: A valid string with the month and day that is 7 days before the birthday, adjusting for month changes.
    """
    day_before = customer.birth_day - 7
    
    if day_before > 0:
        return f"{customer.birth_month} {day_before}"
    else:
        
        month_index = list(days_in_month.keys()).index(customer.birth_month) - 1
        previous_month = list(days_in_month.keys())[month_index]
        
        day_before = days_in_month[previous_month] + day_before
        
        return f"{previous_month} {day_before}"

# eg
c1 = Customer("John Doe", "john@example.com", 1990, "May", 5)
print(birthday_one_week_before(c1))  
