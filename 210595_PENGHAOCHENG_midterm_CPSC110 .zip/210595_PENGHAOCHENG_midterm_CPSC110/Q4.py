class Customer:
    """
    Represents a customer of a restaurant chain.

    purpose: Create a customer with their personal details and their purchase history.
    expect: Customer object with attributes such as name, email, birthday, and purchased items.
    """
    
    def __init__(self, name: str, email: str, birth_year: int, birth_month: int, birth_day: int):
        self.name = name
        self.email = email
        self.birth_year = birth_year
        self.birth_month = birth_month
        self.birth_day = birth_day
        self.items_purchased = {}
    
    def add_item(self, item: str, count: int) -> None:
        """
        purpose: Adds the item to the customer's purchase history. If the item already exists, increase the count.
        expect: The items_purchased dictionary should reflect the correct count for the given item.
        """
        if item in self.items_purchased:
            self.items_purchased[item] += count
        else:
            self.items_purchased[item] = count
#eg

c1 = Customer("John Doe", "john@example.com", 1990, 5, 12)
c1.add_item("Pizza", 2)
c1.add_item("Burger", 1)
c1.add_item("Pizza", 1)  


print(c1.items_purchased)  


