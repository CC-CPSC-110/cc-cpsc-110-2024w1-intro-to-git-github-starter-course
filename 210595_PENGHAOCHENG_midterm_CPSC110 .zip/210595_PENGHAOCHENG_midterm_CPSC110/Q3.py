from typing import List, Union

def fn_for_lon(lon: List[Union[int, float]]) -> List[Union[int, float]]:
    """
    Purpose: Find all the elements in the list that appear the most. 
    Return all elements with the same maximum occurrence in a list.
    
    expect:
    fn_for_lon([1, 2, 3, 4]) -> [1, 2, 3, 4]
    fn_for_lon([1, 2, 2, 3]) -> [2]
    fn_for_lon([1, 1, 2, 2]) -> [1, 2]
    """
    acc = dict()  

    for n in lon:
        if n in acc:
            acc[n] += 1  
        else:
            acc[n] = 1  

    max_count = max(acc.values())

    result = [n for n, count in acc.items() if count == max_count]

    return result  

#eg
print(fn_for_lon([1, 2, 3, 1, 2, 3]))  
print(fn_for_lon([1, 1, 2, 2, 3]))     
print(fn_for_lon([1, 1, 1, 2, 3]))     



