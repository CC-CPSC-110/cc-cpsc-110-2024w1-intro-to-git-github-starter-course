def nextNumber(n: int) -> int:
    """
    Purpose: Given an integer n, return the next integer.
    
    Example:
    nextNumber(3) -> 4
    """
    return n + 1
#eg
print(nextNumber(3))
    
"""
Expected output: 4
"""
