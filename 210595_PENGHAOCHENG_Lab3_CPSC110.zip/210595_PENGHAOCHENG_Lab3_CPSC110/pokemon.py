# Answer Problems 3, 5, and 5 here
from pokemon_api import *

name = get_pokemon_name(132)
attack = get_pokemon_attack("ditto")
defense = get_pokemon_defense("ditto")
types = get_pokemon_num_types("ditto")
type1  = get_pokemon_type1("ditto")
type2 = get_pokemon_type2("ditto")

print(f"{name} | {attack} | {defense} | {types} | {type1} | {type2}")
#Q3
def modified_attack(pokemon_id: int) -> int:
    #stub
    """
    It calculates the modified attack value of a Pokemon.
    modified attack value = attack * types.

    Parameters: pokemon_id (int): The ID of modified pokemon.

    Returns: int: Value of modified attack.
    """
    name = get_pokemon_name(pokemon_id)
    attack = get_pokemon_attack(name)
    num_types = get_pokemon_num_types(name)
    return attack * num_types

#eg
print("pokemon's attack is",modified_attack(1))
#-------------------------------------------------------------------------------------------------------------------------
#Q4
def strongest_pokemon(pokemon_id1: int, pokemon_id2: int) -> str:
    #stub
    """
    This function compares two Pokemon's modified attack and select the larger one.

    Parameters:
    pokemon_id1 (int): The ID of the first Pokemon.
    pokemon_id2 (int): The ID of the second Pokemon.

    Returns:
    - str: The name of the Pokemon with the largest modified attack.
    """
    attack1 = modified_attack(pokemon_id1)
    attack2 = modified_attack(pokemon_id2)
    
    if attack1 > attack2:
        return get_pokemon_name(pokemon_id1)
    elif attack2 > attack1:
        return get_pokemon_name(pokemon_id2)
    else:
        return "Both Pokemon have the same attack value."

print("the stronger pokemon is",strongest_pokemon(1,2))
    
#-------------------------------------------------------------------------------------------------------------------------------
#Q5
    
def inflict_damage(pokemon_id1: int, pokemon_id2: int) -> bool:
    #stub
    """
    This function determines if an attacking Pokemon inflicts damage on a defending Pokemon.
    Damage is inflicted if the attacking Pokemon's modified attack is greater than the defending Pokemon's defense.

    Parameters:
    - attacker_id (int): The ID of the attacking Pokemon.
    - defender_id (int): The ID of the defending Pokemon.

    Returns:
    - bool: True if the attacker inflicts damage, False otherwise.
    """
    attack = modified_attack(pokemon_id1)
    defense = get_pokemon_defense(pokemon_id2)
    if attack > defense:
        return "it does inflicts damage"
    else:
        return "there is no damage"
#eg
print(inflict_damage(4,10))





