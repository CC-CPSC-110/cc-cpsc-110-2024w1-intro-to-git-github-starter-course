from dataclasses import dataclass
from typing import List

@dataclass
class Player:
    """
    Represents the player.

    Signature:
    Player: float, float, float, float, str -> Player
    """
    x: float
    y: float
    size: float
    speed: float
    color: str
    food_count: int = 0  # Keeps track of food collected by the player.

    def move(self, deltaT: float, dirs: List[str]):
        """
        Signature:
        move: (Player, float, List[str]) -> None

        Purpose:
        Moves the player based on keyboard input directions and time delta.

        Example:
        player = Player(0, 0, 10, 300, "red")
        player.move(0.016, ["UP", "LEFT"])
        # Expect player's position (x, y) to be updated based on speed and direction.
        """
        amount = self.speed * deltaT
        if "UP" in dirs:
            self.y -= amount
        if "DOWN" in dirs:
            self.y += amount
        if "LEFT" in dirs:
            self.x -= amount
        if "RIGHT" in dirs:
            self.x += amount

    def move_to_mouse(self, mouse_x: float, mouse_y: float):
        """
        Signature:
        move_to_mouse: (Player, float, float) -> None

        Purpose:
        Moves the player to the specified mouse position (x, y).

        Example:
        player = Player(0, 0, 10, 300, "red")
        player.move_to_mouse(100, 150)
        # Expect player's x and y coordinates to be updated to (100, 150).
        """
        self.x = mouse_x
        self.y = mouse_y

    def eat_food(self):
        """
        Signature:
        eat_food: Player -> None

        Purpose:
        Increases the player's food count and size when food is consumed.

        Example:
        player = Player(0, 0, 10, 300, "red")
        player.eat_food()
        # Expect player's food_count to increase by 1 and size to increase by 2.
        """
        self.food_count += 1
        self.size += 2  # Player increases in size by 2 units for each food item eaten.
