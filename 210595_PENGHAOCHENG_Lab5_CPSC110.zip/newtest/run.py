import pygame
from game_state import Game
from player import Player
from food import FoodList
from keys import pressed_keys, directions

def draw(game_state: Game, player: Player, food_list: FoodList):
    """
    Signature:
    draw: (Game, Player, FoodList) -> None

    Purpose:
    This function draws the player and the food items on the screen.

    Example:
    draw(game_state, player, food_list)
    # This will fill the screen with the background color and then draw the player and each food item.
    """
    game_state.screen.fill(game_state.background)
    pygame.draw.circle(
        game_state.screen,
        player.color,
        pygame.Vector2(player.x, player.y),
        player.size
    )
    
    for food in food_list.food:
        pygame.draw.circle(game_state.screen, (255, 0, 0), pygame.Vector2(food.x, food.y), food.size)
    
    pygame.display.flip()

def main():
    """
    Signature:
    main: None -> None

    Purpose:
    This function initializes the game, manages the game loop, handles player movement,
    food movement, and collision detection between the player and the food.

    Example:
    main()
    # This function sets up the game and runs the main game loop until the user quits.
    """
    pygame.init()
    
    # Define the Game state
    game_state = Game(
        screen     = pygame.display.set_mode((1280, 720)),
        clock      = pygame.time.Clock(),
        background = "purple",
        fps        = 60,
        running    = True,
        deltaT     = 0,
        keymap     = {
            "w": "UP",
            "s": "DOWN",
            "a": "LEFT",
            "d": "RIGHT",
        },
    )

    # Define the player
    player = Player(
        x     = game_state.screen.get_width() / 2,
        y     = game_state.screen.get_height() / 2,
        size  = 40,
        speed = 300,
        color = "red"
    )

    # Initialize FoodList
    food_list = FoodList([])
    food_list.populate(10, game_state.screen.get_width(), game_state.screen.get_height())

    while game_state.running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_state.running = False
                pygame.quit()

        game_state.tick()

        pressed = pressed_keys(pygame.key.get_pressed())
        dirs = directions(game_state.keymap, pressed)

        # Move the player using keyboard input
        player.move(game_state.deltaT, dirs)

        # Move player based on mouse position
        mouse_x, mouse_y = pygame.mouse.get_pos()
        player.move_to_mouse(mouse_x, mouse_y)

        # Move all food items
        food_list.move_all()

        # Check for collisions between player and food
        for food in food_list.food:
            if food.hit(player):
                player.eat_food()
                food_list.remove(food)

        # Draw the game elements
        draw(game_state, player, food_list)

if __name__ == "__main__":
    main()
