from typing import List
from dataclasses import dataclass
import random

@dataclass
class Food:
    x: float
    y: float
    size: float

    def move(self) -> None:
        """
        Signature:
        move: Food -> None

        Purpose:
        Move the food downward on the screen.

        Example:
        food = Food(10, 20, 5)
        food.move()
        # Expect food.y to increase by a random value between 1 and 3.
        """
        self.y += random.uniform(1, 3)  # Random movement speed

    def hit(self, player) -> bool:
        """
        Signature:
        hit: (Food, Player) -> bool

        Purpose:
        Checks if the player has collided with the food.

        Example:
        player = Player(15, 25, 10)
        food = Food(10, 20, 5)
        food.hit(player)
        # Expect True if the player is within touching distance, else False.
        """
        distance = ((self.x - player.x) ** 2 + (self.y - player.y) ** 2) ** 0.5
        return distance < self.size + player.size#by google


@dataclass
class FoodList:
    food: List[Food]

    def populate(self, number_of_food: int, screen_width: int, screen_height: int) -> None:
        """
        Signature:
        populate: (FoodList, int, int, int) -> None

        Purpose:
        This method populates the FoodList with random food positions.

        Example:
        food_list = FoodList([])
        food_list.populate(5, 800, 600)
        # Expect food_list to have 5 random food items within screen width and height.
        """
        for _ in range(number_of_food):
            x = random.uniform(0, screen_width)
            y = random.uniform(0, screen_height / 2)  # Food appears in the upper half of the screen
            size = random.uniform(10, 20)  # Food size ranges between 10 and 20
            self.food.append(Food(x, y, size))

    def move_all(self) -> None:
        """
        Signature:
        move_all: FoodList -> None

        Purpose:
        This method moves all food items in the list.

        Example:
        food_list.move_all()
        # Expect all food objects' y positions to increase.
        """
        for f in self.food:
            f.move()

    def remove(self, food: Food) -> None:
        """
        Signature:
        remove: (FoodList, Food) -> None

        Purpose:
        This method removes a specific food from the list.

        Example:
        food = food_list.food[0]
        food_list.remove(food)
        # Expect the first food item to be removed from the list.
        """
        self.food.remove(food)


# Code Summary:
# providing functionality to move the food and detect if the player has collided with it.
# The FoodList class handles a collection of food objects, allowing food to be randomly generated,
# moved, and removed. The code follows the HtDF method, providing clear signatures, purposes,
# and examples to aid in understanding and testing.

 
 