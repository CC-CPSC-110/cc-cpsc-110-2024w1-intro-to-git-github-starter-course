import unittest
from player import Player
from food import Food, FoodList

class TestGame(unittest.TestCase):
    def test_move_food(self):
        food = Food(0, 0, 10)
        initial_y = food.y
        food.move()
        self.assertGreater(food.y, initial_y)

    def test_player_eats_food(self):
        player = Player(0, 0, 10, 0, "red")
        food = Food(5, 0, 10)
        self.assertTrue(food.hit(player))

    def test_player_moves_to_mouse(self):
        player = Player(0, 0, 10, 0, "red")
        player.move_to_mouse(100, 100)
        self.assertEqual(player.x, 100)
        self.assertEqual(player.y, 100)

if __name__ == '__main__':
    unittest.main()
