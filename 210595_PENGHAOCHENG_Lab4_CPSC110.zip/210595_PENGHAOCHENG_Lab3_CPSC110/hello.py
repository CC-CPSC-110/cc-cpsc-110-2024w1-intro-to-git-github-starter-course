# Answer Problem 1 here
def hello_world(s: str) -> str:
    """
    This function accepts a string and returns "Hello world! " followed by the input string.
    
    Parameters:- s (str): The input string to which "Hello world!" will be added in front of s.

    Returns:- str: The input string with "Hello world! " at the beginning.
    """
    return "Hello world! " + s

#eg
print(hello_world("welcome")) 
