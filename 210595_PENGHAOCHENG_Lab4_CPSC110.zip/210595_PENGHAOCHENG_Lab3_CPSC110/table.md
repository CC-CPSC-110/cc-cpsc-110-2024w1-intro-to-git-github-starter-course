# Pokemon Table

| ID  | Name  | Attack | Defense | Number of Types | Type 1 | Type 2 |
|-----|-------|--------|---------|-----------------|--------|--------|
| 32  | Ditto | 48     | 48      | 1               | normal | None   |
| 24  | Pikachu | 55   | 40      | 1               | electric | None |
| 3   | Bulbasaur | 49 | 49      | 2               | grass  | poison |
