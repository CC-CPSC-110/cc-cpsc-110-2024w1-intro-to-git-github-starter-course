# Answer Problems 3, 5, and 5 here
from pokemon_api import *

class Pokemon:
    def __init__(self, name, attack, defense, num_types, type1, type2, hp=100):
        """
        Initialize a new Pokemon with the given attributes.
        
        Parameters:
        - name (str): The name of the Pokemon.
        - attack (int): The Pokemon's attack value.
        - defense (int): The Pokemon's defense value.
        - num_types (int): The number of types the Pokemon has.
        - type1 (str): The primary type of the Pokemon.
        - type2 (str): The secondary type of the Pokemon (if applicable).
        - hp (int): The hit points (HP) of the Pokemon, defaulting to 100.
        """
        self.name = name
        self.attack = attack
        self.defense = defense
        self.num_types = num_types
        self.type1 = type1
        self.type2 = type2
        self.hp = hp  # Default HP of 100
    
    def __repr__(self):
        return f"{self.name}: {self.attack} attack, {self.defense} defense, {self.hp} hp"

#Q3
def modified_attack(pokemon_id: int) -> int:
    #stub
    """
    It calculates the modified attack value of a Pokemon.
    modified attack value = attack * types.

    Parameters: pokemon_id (int): The ID of modified pokemon.

    Returns: int: Value of modified attack.
    """
    name = get_pokemon_name(pokemon_id)
    attack = get_pokemon_attack(name)
    num_types = get_pokemon_num_types(name)
    return attack * num_types

#eg
print("pokemon's attack is",modified_attack(1))
#-------------------------------------------------------------------------------------------------------------------------
#Q4
def strongest_pokemon(pokemon_id1: int, pokemon_id2: int) -> str:
    #stub
    """
    This function compares two Pokemon's modified attack and select the larger one.

    Parameters:
    pokemon_id1 (int): The ID of the first Pokemon.
    pokemon_id2 (int): The ID of the second Pokemon.

    Returns:
    - str: The name of the Pokemon with the largest modified attack.
    """
    attack1 = modified_attack(pokemon_id1)
    attack2 = modified_attack(pokemon_id2)
    
    if attack1 > attack2:
        return get_pokemon_name(pokemon_id1)
    elif attack2 > attack1:
        return get_pokemon_name(pokemon_id2)
    else:
        return "Both Pokemon have the same attack value."

print("the stronger pokemon is",strongest_pokemon(1,2))
    
#-------------------------------------------------------------------------------------------------------------------------------
#Q5
    
def inflict_damage(pokemon_id1: int, pokemon_id2: int) -> bool:
    #stub
    """
    This function determines if an attacking Pokemon inflicts damage on a defending Pokemon.
    Damage is inflicted if the attacking Pokemon's modified attack is greater than the defending Pokemon's defense.

    Parameters:
    - attacker_id (int): The ID of the attacking Pokemon.
    - defender_id (int): The ID of the defending Pokemon.

    Returns:
    - bool: True if the attacker inflicts damage, False otherwise.
    """
    attack = modified_attack(pokemon_id1)
    defense = get_pokemon_defense(pokemon_id2)
    if attack > defense:
        return "it does inflicts damage"
    else:
        return "there is no damage"
#eg
print(inflict_damage(4,10))

#---------------------------------------------------------------------------------------
#Q6
def damage(pokemon: Pokemon, amount: int) -> Pokemon:
    """
    Reduces the Pokemon's HP by the given damage amount.
    
    Parameters:
    - pokemon (Pokemon): The Pokemon receiving the damage.
    - amount (int): The amount of damage to reduce HP by.
    
    Returns:
    - Pokemon: The Pokemon with updated HP.
    """
    pokemon.hp -= amount 
    if pokemon.hp < 0:  
        pokemon.hp = 0
    return pokemon

charizard = Pokemon("Charizard", 84, 78, 2, "fire", "flying", 150)  
print(f"Before damage: {charizard.hp} HP")  
charizard = damage(charizard, 50)  
print(f"After damage: {charizard.hp} HP")  
     

#----------------------------------------------------------------------------------------
#Q7
def update_database(database: list, updated_pokemon: Pokemon) -> list:
    """
    Updates the database with the modified Pokemon.
    
    Parameters:
    - database (list): A list of Pokemon objects.
    - updated_pokemon (Pokemon): The Pokemon to be updated in the database.

    Returns:
    - list: The updated database.
    """
    for i, pokemon in enumerate(database):
        if pokemon.name == updated_pokemon.name:
            database[i] = updated_pokemon
            break
    return database

database = [
    Pokemon("Pikachu", 55, 40, 1, "electric", None),
    Pokemon("Bulbasaur", 49, 49, 2, "grass", "poison", 90)
]

updated_pikachu = Pokemon("Pikachu", 60, 40, 1, "electric", None, 80)

updated_database = update_database(database, updated_pikachu)

for pokemon in updated_database:
    print(pokemon)
    
#-------------------------------------------------------------------------------------------
#Q8
def simulate_attack(attacker: Pokemon, defender: Pokemon) -> str:
    """
    Simulates an attack between two Pokemon.
    
    Parameters:
    - attacker (Pokemon): The attacking Pokemon.
    - defender (Pokemon): The defending Pokemon.
    
    Returns:
    - str: The result of the attack.
    """
    if inflict_damage(attacker, defender):
        damage_amount = attacker.attack * attacker.num_types
        defender = damage(defender, damage_amount)
        return f"{attacker.name} attacked {defender.name} and inflicted {damage_amount} damage. {defender.name} now has {defender.hp} HP."
    else:
        return f"{attacker.name} attacked {defender.name}, but it had no effect."

#eg:
pikachu = Pokemon("Pikachu", 55, 40, 1, "electric", None)
bulbasaur = Pokemon("Bulbasaur", 49, 49, 2, "grass", "poison", 90)

result = simulate_attack(pikachu, bulbasaur)
print(result)  






