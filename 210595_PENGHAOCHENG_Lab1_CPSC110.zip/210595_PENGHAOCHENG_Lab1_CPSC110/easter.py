import math

x = int(input('year you want to check:')) #Input the starting year and set x just to make the following steps easier

a = int(x/100)
b = int(x%100)
c = int(b/4)            
d = int(b%4)
e = int(x%19)
f = int(a%4)
g = int(a/4)
h = int((a+8)/25)
i = int((a-h+1)/3)
j = int((19*e+a-g-i+15)/30)
k = int((32+2*f+2*c)/7)
l = int((e+11*j+22*k)/451)
m = int((j+k-7*l+114)/31)
da= int((j+k-7*l+114)/31)
date = str(da)+str(m)+str(x) #transfer integer into str to show the whole date.

print(a,b,c,d,e,f,g,h,i,j,k,l,m,da) #help to check if there is mistake.
print(date) #print outcomes