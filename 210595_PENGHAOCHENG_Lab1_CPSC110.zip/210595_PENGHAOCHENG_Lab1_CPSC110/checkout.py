vp = float(input('Please Enter the Price of Your Purchase:')) #get the number of value of purchase price


gst = float(vp*0.05) #get gst tax
pst = float(vp*0.07) #get pst tax
total = float(vp+gst+pst) #total money should paid

print('GST: $',gst) 
print('PST: $',pst) 
print('Total: $',total)

cp = float(input('Enter cash paid:')) #cash paid input
mc = float(cp-total) #get the money change should reurn

tenner = int(mc/10) #calculate how many of each kind of coin should return to costumer.
r1 = mc%10 #after calculated former coin type, use the remaining number to divid and get the number of next coin type
fin = int(r1/5)
r2 = r1%5
toonie = int(r2/2)
r3 = r2%2
loonie = int(r3/1)
r4 = r3%1
quarter = int(r4/0.25)
r5 = r4%0.25
dime = int(r5/0.1)
r6 = r5%0.1
nickel = int(r6/0.05)
r7 = r6%0.05
penny = int(r7/0.01)

print('Tenner:',tenner) #print all the coin type and quantity owed.
print('Fin:',fin)
print('Toonie：',toonie)
print('Loonie：',loonie)
print('Quarter:', quarter)
print('Dime:', dime)
print('Nickel:', nickel)
print('Penny:', penny)
    


