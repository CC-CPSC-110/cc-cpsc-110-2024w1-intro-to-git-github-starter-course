import math

x = int(input('four digital number:'))
d1 = x//1000
d2 = (x//100)%10
d3 = (x%100)//10
d4 = x%10
print(d1)
print(d2)
print(d3)
print(d4)

sum_of_numbers = d1+d2+d3+d4
print(sum_of_numbers)

product = d1*d2*d3*d4
print(product)

print(str(d4)+str(d3)+str(d2)+str(d1))

double=x*2
print(double)

roots = math.sqrt(x)
print(roots)