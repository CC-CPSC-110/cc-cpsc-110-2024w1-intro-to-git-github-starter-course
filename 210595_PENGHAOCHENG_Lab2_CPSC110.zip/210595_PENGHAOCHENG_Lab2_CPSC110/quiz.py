score = 0
corrects = 0
total_questions = 5

print("Welcome to the easiest Quiz!")
print("You will be asked 5 questions. you best to get them all right.")
print("Let's begin!")
# Q1
print("Question 1: What is 1 + 1?")
answer = int(input("Please enter your answer: "))
if answer == 2:
    print("Correct! 1 + 1 is 2.")
    score += 20
    corrects +=1
else:
    print("Wrong. The correct answer is 2.")

# Q2
print("Question 2: What is the capital of Canada?")
answer = input("Please enter your answer: ")  
if answer == "Ottawa":
    print("Correct! The capital of France is Ottawa.")
    score += 20
    corrects +=1
else:
    print("Wrong. The correct answer is Ottawa.")

# Q3
print("Question 3: What is 5 ^ 3?")
answer = int(input("Please enter your answer: "))
if answer == 125:
    print("Correct! 5 ^ 3 is 125.")
    score += 20
    corrects += 1
else:
    print("Wrong. The correct answer is 125.")

print("Question 4: What is the highest score you can get on this quiz?")
answer = input("Please enter your answer: ")

if answer == "100":
    print("Correct!.")
    score += 20
    corrects += 1
else:
    print("Wrong. The correct answer is 100.")
# Q5
print("Question 5: What score can I get on this quiz?")
print("A. 100")
print("B. Full mark")
print("C. Absolutely perfect")
answer = input("Please enter A, B, or C: ")

if answer == "A" or answer == "B" or answer == "C":
    print("awesome!")
    score += 20
    corrects += 1
else:
    print("Wrong. The correct answers were A, B, or C.")

print("You got", corrects, "out of", total_questions, "questions right.")
print("that is a socore of", score,"percent.")

