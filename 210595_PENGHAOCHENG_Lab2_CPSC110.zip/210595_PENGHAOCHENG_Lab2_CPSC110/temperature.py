import math

t = float(input("Enter the temperature: "))
cu = input("Enter the current unit (Celsius, Fahrenheit, Kelvin): ")
cvt = input("Enter the unit you want to convert to (Celsius, Fahrenheit, Kelvin): ")


if cu == "Celsius" and cvt == "Fahrenheit":
    result = (t * 9/5) + 32
    print(f"The temperature in Fahrenheit is {result}.")
elif cu == "Celsius" and cvt == "Kelvin":
    result = t + 273
    print(f"The temperature in Kelvin is {result}.")
elif cu == "Fahrenheit" and cvt == "Celsius":
    result = (t - 32) * 5/9
    print(f"The temperature in Celsius is {result}.")
elif cu == "Fahrenheit" and cvt == "Kelvin":
    result = (t - 32) * 5/9 + 273
    print(f"The temperature in Kelvin is {result}.")
elif cu == "Kelvin" and cvt == "Celsius":
    result = t - 273
    print(f"The temperature in Celsius is {result}.")
elif cu == "Kelvin" and cvt == "Fahrenheit":
    result = (t - 273) * 9/5 + 32
    print(f"The temperature in Fahrenheit is {result}.")
#Modified using chatgpt here.
elif cu == "Celsius" and cvt == "Celsius":
    result = t  
    print(f"The temperature in Celsius is {result}.")
elif cu == "Fahrenheit" and cvt == "Fahrenheit":
    result = t  
    print(f"The temperature in Fahrenheit is {result}.")
elif cu == "Kelvin" and cvt == "Kelvin":
    result = t  
    print(f"The temperature in Kelvin is {result}.")
else:
    print("Invalid input.")
