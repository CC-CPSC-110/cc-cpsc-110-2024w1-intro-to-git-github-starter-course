month = input("Enter the month(capitalized the first letter): ")
day = int(input("Enter the month as an integer: "))


s = ""


if month == "March" and day >= 20:s = "Spring"

elif month == "April" or month == "May":s = "Spring"
elif month == "June" and day < 21:s = "Spring"
elif month == "June" and day >= 21:s = "Summer"
elif month == "July" or month == "August":s = "Summer"
elif month == "September" and day < 22:s = "Summer"
elif month == "September" and day >= 22:s = "Fall"
elif month == "October" or month == "November":s = "Fall"
elif month == "December" and day < 21:s = "Fall"
elif month == "December" and day >= 21:s = "Winter"
elif month == "January" or month == "February":s = "Winter"
elif month == "March" and day < 20:s = "Winter"


print("The season is", month, day, s + ".")

