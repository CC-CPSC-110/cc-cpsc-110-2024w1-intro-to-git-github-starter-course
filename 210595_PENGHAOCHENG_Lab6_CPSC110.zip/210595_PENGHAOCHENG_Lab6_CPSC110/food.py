from typing import List
from dataclasses import dataclass
import random
from sprite import Sprite  # Import the Sprite class

@dataclass
class Food(Sprite):
    """
    Represents food in the game that the player and opponent can eat.
    Inherits from Sprite.
    """
    
    def move(self) -> None:
        """
        Moves the food item down the screen randomly by adding a random value to the y-coordinate.
        The random value is between 1 and 3.
        """
        self.y += random.uniform(1, 3)
    
    def hit(self, player) -> bool:
        """
        Checks if the food has collided with the player by measuring the distance between them.
        
        Parameters:
        player (Player): The player to check collision with.
        
        Returns:
        bool: True if the distance between the food and player is less than the sum of their sizes.
        """
        distance = ((self.x - player.x) ** 2 + (self.y - player.y) ** 2) ** 0.5
        return distance < self.size + player.size

@dataclass
class FoodList:
    """
    Represents a collection of food items in the game.
    
    Attributes:
    food (List[Food]): A list of Food objects currently in the game.
    """
    food: List[Food]

    def populate(self, number_of_food: int, screen_width: int, screen_height: int) -> None:
        """
        Populates the food list with randomly positioned food items.
        
        Parameters:
        number_of_food (int): The number of food items to generate.
        screen_width (int): The width of the game screen.
        screen_height (int): The height of the game screen. Food is generated in the upper half of the screen.
        """
        for _ in range(number_of_food):
            x = random.uniform(0, screen_width)
            y = random.uniform(0, screen_height / 2)
            size = random.uniform(10, 20)
            self.food.append(Food(x, y, size))

    def move_all(self) -> None:
        """
        Moves all food items in the food list by calling their move method.
        """
        for f in self.food:
            f.move()

    def remove(self, food: Food) -> None:
        """
        Removes a specific food item from the list, typically after it has been eaten by the player or opponent.
        
        Parameters:
        food (Food): The food item to remove from the list.
        """
        self.food.remove(food)

