from dataclasses import dataclass
from player import Player  # Opponent inherits from Player

@dataclass
class Opponent(Player):
    """
    Represents the opponent character, which moves towards food to eat it before the player.
    Inherits from Player, sharing common attributes such as position, speed, and size.
    """
    
    def move(self, deltaT: float, target_x: float, target_y: float):
        """
        Moves the opponent towards a target position (e.g., food).
        
        Parameters:
        deltaT (float): Time passed between frames for smooth movement.
        target_x (float): The target's x position (e.g., the food's x-coordinate).
        target_y (float): The target's y position (e.g., the food's y-coordinate).
        
        The opponent's position (x, y) is updated based on its speed and direction towards the target.
        """
        if target_x > self.x:
            self.x += self.speed * deltaT
        elif target_x < self.x:
            self.x -= self.speed * deltaT

        if target_y > self.y:
            self.y += self.speed * deltaT
        elif target_y < self.y:
            self.y -= self.speed * deltaT


