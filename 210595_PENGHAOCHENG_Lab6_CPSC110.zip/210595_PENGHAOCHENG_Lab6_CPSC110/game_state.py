"""Manages Game state."""
import sys
from typing import Dict
from dataclasses import dataclass
import pygame

# Get the Python version as a tuple
python_version = sys.version_info

if python_version >= (3, 11):
    # Import for Python 3.11 and above
    from typing import Self
else:
    # Import for Python versions below 3.11
    from typing_extensions import Self

@dataclass 
class Game:
    """
    Represents all data necessary to run a game instance.

    Signature:
    Game: pygame.Surface, pygame.time.Clock, Dict[str, str], str, float, bool, float -> Game
    """
    screen: pygame.Surface
    clock: pygame.time.Clock
    keymap: Dict[str, str]
    background: str
    fps: float
    running: bool
    deltaT: float  # The delta time is change in time in seconds since last frame.

    def tick(self) -> Self:
        """
        Signature:
        tick: Game -> Game

        Purpose:
        Limits FPS and ensures framerate-independent physics by updating delta time.

        Example:
        game = Game(screen, clock, keymap, "blue", 60, True, 0)
        game.tick()
        # Expect game.deltaT to be updated based on clock tick.
        """
        self.deltaT = self.clock.tick(self.fps) / 1000
        return self
    #Due to time constraints, I directly followed ChatGPT's suggestion for this part, but I will rewrite it myself later
