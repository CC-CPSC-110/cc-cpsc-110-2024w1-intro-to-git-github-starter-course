from dataclasses import dataclass

@dataclass
class Sprite:
    """
    Represents common properties for any sprite in the game.
    Signature:
    Sprite: float, float, float -> Sprite
    """
    x: float
    y: float
    size: float
