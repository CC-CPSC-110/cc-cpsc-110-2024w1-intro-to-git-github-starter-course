@dataclass
class Character(Sprite):
    speed: float
    color: str

    def move(self, deltaT: float, direction: List[str]):
        # Shared move logic for player and opponent
        amount = self.speed * deltaT
        if "UP" in direction:
            self.y -= amount
        if "DOWN" in direction:
            self.y += amount
        if "LEFT" in direction:
            self.x -= amount
        if "RIGHT" in direction:
            self.x += amount
