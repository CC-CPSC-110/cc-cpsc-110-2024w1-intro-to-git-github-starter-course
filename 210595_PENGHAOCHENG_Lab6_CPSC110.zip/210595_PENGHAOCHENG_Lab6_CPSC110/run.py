import pygame
from game_state import Game
from player import Player
from food import FoodList
from keys import pressed_keys, directions
from opponent import Opponent  # Import Opponent

def draw(game_state: Game, characters, food_list: FoodList):
    """
    Signature:
    draw: (Game, List[Character], FoodList) -> None

    Purpose:
    This function draws all characters (player and opponent) and all food items on the screen.
    It now works by treating both player and opponent as `Character` objects, reducing duplication.
    """
    # Fill the screen with the background color
    game_state.screen.fill(game_state.background)
    
    # Draw all characters (player, opponent)
    for character in characters:
        pygame.draw.circle(game_state.screen, character.color, pygame.Vector2(character.x, character.y), character.size)

    # Draw all food items
    for food in food_list.food:
        pygame.draw.circle(game_state.screen, (255, 0, 0), pygame.Vector2(food.x, food.y), food.size)

    # Update the display
    pygame.display.flip()

def main():
    pygame.init()
    
    # Define the Game state
    game_state = Game(
        screen     = pygame.display.set_mode((1280, 720)),
        clock      = pygame.time.Clock(),
        background = "purple",
        fps        = 60,
        running    = True,
        deltaT     = 0,
        keymap     = {
            "w": "UP",
            "s": "DOWN",
            "a": "LEFT",
            "d": "RIGHT",
        },
    )

    # Define the player
    player = Player(
        x     = game_state.screen.get_width() / 2,
        y     = game_state.screen.get_height() / 2,
        size  = 40,
        speed = 300,
        color = "red"
    )

    # Define the opponent
    opponent = Opponent(
        x     = 100,  # Opponent starting position
        y     = 100,
        size  = 40,
        speed = 250,
        color = "blue"
    )

    # Initialize FoodList
    food_list = FoodList([])
    food_list.populate(10, game_state.screen.get_width(), game_state.screen.get_height())

    while game_state.running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_state.running = False
                pygame.quit()

        game_state.tick()

        # Move player using keyboard input
        pressed = pressed_keys(pygame.key.get_pressed())
        dirs = directions(game_state.keymap, pressed)
        player.move(game_state.deltaT, dirs)

        # Move player based on mouse position
        mouse_x, mouse_y = pygame.mouse.get_pos()
        player.move_to_mouse(mouse_x, mouse_y)

        # Move opponent towards the closest food
        if food_list.food:
            closest_food = food_list.food[0]  # Simplified: Take the first food item
            opponent.move(game_state.deltaT, closest_food.x, closest_food.y)

        # Move all food items
        food_list.move_all()

        # Check for collisions between player and food
        for food in food_list.food:
            if food.hit(player):
                player.eat_food()
                food_list.remove(food)

        # Check for collisions between opponent and food
        for food in food_list.food:
            if food.hit(opponent):
                opponent.size += 2  # Opponent also grows by 2 when it eats food
                food_list.remove(food)

        # Draw the game elements (player, opponent, food)
        draw(game_state, [player, opponent], food_list)

if __name__ == "__main__":
    main()
