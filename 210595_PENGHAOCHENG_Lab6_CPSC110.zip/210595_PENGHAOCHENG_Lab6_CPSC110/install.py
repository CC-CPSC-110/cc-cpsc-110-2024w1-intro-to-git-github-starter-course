from cs110 import install

install("typing_extensions")