from dataclasses import dataclass
from typing import List
from sprite import Sprite  # Assuming Sprite is defined in sprite.py

@dataclass
class Player(Sprite):
    """
    Represents the player character in the game, who can move and collect food.
    Inherits from Sprite, sharing attributes such as position, size, and speed.

    Attributes:
    speed (float): The speed at which the player moves.
    color (str): The color of the player.
    food_count (int): The number of food items the player has collected, initially set to 0.
    """
    speed: float
    color: str
    food_count: int = 0  # Keeps track of food collected by the player.

    def move(self, deltaT: float, dirs: List[str]):
        """
        Moves the player based on keyboard input directions and delta time.
        
        Parameters:
        deltaT (float): The time passed between frames for smooth movement.
        dirs (List[str]): A list of directions such as 'UP', 'DOWN', 'LEFT', 'RIGHT' to move the player.
        
        The player's position (x, y) is updated based on the specified directions and speed.
        """
        amount = self.speed * deltaT
        if "UP" in dirs:
            self.y -= amount
        if "DOWN" in dirs:
            self.y += amount
        if "LEFT" in dirs:
            self.x -= amount
        if "RIGHT" in dirs:
            self.x += amount

    def move_to_mouse(self, mouse_x: float, mouse_y: float):
        """
        Moves the player to the specified mouse position (x, y).
        
        Parameters:
        mouse_x (float): The x-coordinate of the mouse position.
        mouse_y (float): The y-coordinate of the mouse position.
        
        The player's position is updated to the new mouse coordinates.
        """
        self.x = mouse_x
        self.y = mouse_y

    def eat_food(self):
        """
        Increases the player's food count and size when food is consumed.
        The player grows by 2 units for each food item eaten.
        """
        self.food_count += 1
        self.size += 2  # Player increases in size by 2 units for each food item eaten.
